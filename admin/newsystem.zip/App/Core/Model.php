<?php

namespace Pemm\Core;

abstract class Model extends Core
{
    public $queryTotalCount = 0;
    public $queryTotalPage = 0;
}
