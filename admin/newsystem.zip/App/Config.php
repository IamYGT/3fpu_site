<?php
namespace Pemm;
class Config
{
    public $LICENSE_KEY = 'PRO-KFPOE-GVJZK-AWSHK';
    const DB_HOST = '127.0.0.1';
    const DB_NAME = 'proecu_dark';
    const DB_USER = 'proecu_dark';
    const DB_PASSWORD = 'e7h47mF5_';
    const SHOW_ERRORS = true;
    const SECRET_KEY = 'E)HK@McQfZTjWnZr4t7w!z%C*F-JaNdRgU';
    const THUMP_SIZE = 300;
    const TMP_DIR = 'tmp_images/';

}
