<?php

namespace Pemm\Controller;

use Pemm\Core\Controller as CoreController;
use Pemm\Core\View;
use Pemm\Model\Customer;
use Pemm\Model\EmailNotification;
use Pemm\Model\Helper;
use Pemm\Model\Page;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Session\Session;
use Pemm\Model\Support as SupportModel;
use Pemm\Controller\Sms;
use Pemm\Model\SmsProvider;

class Support extends CoreController
{
    public function index()
    {
        try {

            /* @var Customer $customer */
            $customer = $this->container->get('customer');

            if ($this->request->isMethod('post')) {

                $subject = $this->request->request->get('subject');
                $text = $this->request->request->get('text');
                $vehicle = $this->request->request->get('vehicle');

                if (!empty($subject) && !empty($text)) {
                    $support = new SupportModel();
                    $support
                        ->setReference($customer->getId() . Helper::generateRandomString(24))
                        ->setSubject($subject)
                        ->setVehicle($vehicle)
                        ->setText($text)
                        ->setType('customer')
                        ->setCustomer($customer)
                        ->setCustomerRead(1)
                        ->setAdministratorRead(0)
                        ->setFirstQuestion(1)
                        ->setStatus('pending');

                    if (!empty($this->request->files->get('file'))) {
                        $file = $this->request->files->get('file');
                        $movedFile = $file->move(
                            $_SERVER['DOCUMENT_ROOT'] . '/files/',
                            'support-file-' . time() . '.' . $file->getClientOriginalExtension()
                        );
                        $support->setFile($movedFile->getFilename());
                    }

                    $support->store();

                    $smsProvider = (new SmsProvider())->find(1);
                    $account_sid = trim($smsProvider->getToken());
                    if (!empty($account_sid)) {
                        (new Sms())->customerCreateSupport($text);
                    }
                    (new EmailNotification())->send('support', 'new', $support);

                    if ($support->getId()) {
                        (new RedirectResponse('/panel/ticket?ticket_id=' . $support->getId()))->send();
                    }
                }
            }

            $this->container->set(
                'page',
                (new Page())
                    ->setType('support')
                    ->setUrl($this->request->getBasePath() . $this->request->getRequestUri())
                    ->setMetaTitle('Destek Talepleri - ' . $this->setting->getSiteName())
                    ->setMetaDescription('Destek Talepleri - ' . $this->setting->getDescription())
            );

        } catch (\Exception $exception) {
            print_r($exception);
            die;
        }

        View::render('customer', 'destek-talepleri', []);
    }

    public function detail()
    {
        /* @var Customer $customer */
        $customer = $this->container->get('customer');

        if ($this->request->isMethod('post')) {
            $subject = $this->request->request->get('subject');
            $text = $this->request->request->get('text');
            $vehicle = $this->request->request->get('vehicle');

            if (!empty($subject) && !empty($text)) {
                $support = new SupportModel();
                $support
                    ->setReference($customer->getId() . Helper::generateRandomString(24))
                    ->setSubject($subject)
                    ->setVehicle($vehicle)
                    ->setText($text)
                    ->setType('customer')
                    ->setCustomer($customer)
                    ->setCustomerRead(1)
                    ->setAdministratorRead(0)
                    ->setFirstQuestion(1)
                    ->setStatus('pending');

                if (!empty($this->request->files->get('file'))) {
                    $file = $this->request->files->get('file');
                    $movedFile = $file->move(
                        $_SERVER['DOCUMENT_ROOT'] . '/files/',
                        'support-file-' . time() . '.' . $file->getClientOriginalExtension()
                    );
                    $support->setFile($movedFile->getFilename());
                }

                $support->store();

                (new Sms())->customerCreateSupport($text);
                (new EmailNotification())->send('support', 'new', $support);

                if ($support->getId()) {
                    (new RedirectResponse('/panel/ticket?ticket_id=' . $support->getId()))->send();
                }
            }
        } else {

            $this->container->set('supportType', 'customer');

            $ticket_id = $this->request->query->get('ticket_id');

            $support = (new SupportModel())->find($ticket_id);

            if (!empty($support) && $support->customer->getId() == $customer->getId()) {
                $support->read('customer');
                $this->container->set('support', $support);
            }


            View::render('customer', 'destek-detay', []);
        }

    }

    public function close()
    {
        $type = 'closed';

        /* @var Customer $customer */
        $customer = $this->container->get('customer');

        if (!empty($id = $this->route_params['id'])) {

            $support = (new SupportModel())->find($id);

            if (
                !empty($support) &&
                $support->customer->getId() == $customer->getId()
            ) {
                $support->setStatus('closed');
                $support->store();
            }

            (new RedirectResponse('/panel/support?type=closed&read=1'))->send();
        }
    }

    public function ajaxSupportDetail()
    {
        $id = $this->route_params['id'];

        /* @var Customer $customer */
        $customer = $this->container->get('customer');

        $this->container->set('supportType', 'customer');

        $support = (new SupportModel())->find($id);

        if (!empty($support) && $support->customer->getId() == $customer->getId()) {
            $support->read('customer');
            $this->container->set('support', $support);
            View::render('customer', 'ajax/support-detail', []);
        }
    }

    public function ajaxSendMessage()
    {
        try {

            $id = $this->route_params['id'];

            /* @var Customer $customer */
            $customer = $this->container->get('customer');

            $this->container->set('supportType', 'customer');

            $support = (new SupportModel())->find($id);

            if (!empty($support) && $support->customer->getId() == $customer->getId()) {
                $support->read('customer');
                $this->container->set('support', $support);

                if (
                    !empty($this->request->request->has('message')) ||
                    !empty($this->request->files->get('file'))
                ) {

                    $newSupportMessage = new SupportModel();
                    $newSupportMessage
                        ->setReference($support->getReference())
                        ->setVehicle($support->getVehicle())
                        ->setSubject('')
                        ->setType('customer')
                        ->setCustomer($customer)
                        ->setCustomerRead(1)
                        ->setAdministratorRead(0)
                        ->setFirstQuestion(0)
                        ->setStatus('pending');


                    if ($this->request->request->has('message')) {
                        $newSupportMessage->setText($this->request->request->get('message'));
                    }

                    if (!empty($this->request->files->get('file'))) {
                        $file = $this->request->files->get('file');
                        $movedFile = $file->move(
                            $_SERVER['DOCUMENT_ROOT'] . '/files/',
                            'support-file-' . time() . '.' . $file->getClientOriginalExtension()
                        );
                        $newSupportMessage->setFile($movedFile->getFilename());
                    }

                    $newSupportMessage->store();

                    (new Sms())->customerReplySupport($this->request->request->get('message'));
                    (new EmailNotification())->send('support', 'reply', $newSupportMessage);

                    View::render('customer', 'ajax/support-detail', []);
                }

            }

        } catch (\Exception $exception) {
            print_r($exception);
        }
    }
}
