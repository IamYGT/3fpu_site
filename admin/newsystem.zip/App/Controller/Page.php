<?php

namespace Pemm\Controller;

use Pemm\Core\Controller as CoreController;
use Pemm\Core\View;
use Pemm\Model\AdditionalPage;
use Pemm\Model\Page as PageModel;
use Pemm\Model\Category;
use Symfony\Component\HttpFoundation\RedirectResponse;

class Page extends CoreController
{
    public function index()
    {

    }
}
