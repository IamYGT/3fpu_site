<?php

namespace Pemm\Model\DTO;

class VehicleTuningAdditionalOptionDTO
{
    /**
     * @var int
     */
    public $id;

    /**
     * @var int
     */
    public $isActive;
}
