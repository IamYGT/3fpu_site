<?php

namespace Pemm\Model\DTO;

class VehicleReadMethodDTO
{
    /**
     * @var int
     */
    public $id;

    /**
     * @var int
     */
    public $isActive;
}
